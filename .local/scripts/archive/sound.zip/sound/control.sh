#!/bin/bash
vol=$(cat $HOME/.config/sound/volume)
if [ "$1" = "inc" ]; then
	vol=$( expr $vol + 5)
	pactl set-sink-volume @DEFAULT_SINK@ $vol\% &
	echo $vol > $HOME/.config/sound/volume &
elif [ "$1" = "dec" ]; then
	vol=$( expr $vol - 5)
	pactl set-sink-volume @DEFAULT_SINK@ $vol\% &
	echo $vol > $HOME/.config/sound/volume &
elif [ "$1" = "mute" ]; then
	vol=$(($vol * -1))
	echo $vol > $HOME/.config/sound/volume &
	pactl set-sink-mute   @DEFAULT_SINK@ toggle &
else
	exit 1
fi

wait

exit 0
