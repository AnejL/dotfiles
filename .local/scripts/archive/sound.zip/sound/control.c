#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#define BUFSIZE 5
#define err(mess) { fprintf(stderr,"Error: %s.\n", mess); exit(1); }

int comparestrings(char* input, char* template) {
	
	int i;
	char inchar, tempchar;
	for (i = 0; ;i++) {
		inchar = input[i];
		tempchar = template[i];
		
		if (inchar != tempchar)
			return 1;
		
		if (inchar == '\0')
			break;
	}
	return 0;
}

int main(int argc, char* argv[]) {
	// check if you have enough arguments
	if (argc < 2)
		err("Not enough arguments!");

	// get the config location
	char* envhome = getenv("HOME");
	char buf[50];
	strcpy(buf, envhome);
	strcat(buf, "/.config/sound/volume");

	//printf("Location: %s\n", buf);

	// open the file
	int fd = open(buf, O_RDWR);
	
	char readbuffer[BUFSIZE];
	int n;	
	while ( (n = read(fd, readbuffer, BUFSIZE)) > 0 ) {
		//printf("read %d bytes\n", n);
	}

	// current sound value and change value
	unsigned int soundval, delta;
	soundval = atoi(readbuffer);
	
	if (argc > 2)
		delta = atoi(argv[2]);

	// if string equals inc dec or mute
	if (comparestrings(argv[1], "inc") == 0 && soundval >= 0) {
		soundval = soundval + delta;
	}
	else if (comparestrings(argv[1], "dec") == 0 &&  soundval >= 0 ) {
		soundval = soundval - delta;	
	}
	else if (comparestrings(argv[1], "mute") == 0) {
		soundval = soundval * -1;
	}
	else 
		err("Usage: soundmgr [inc NUM |dec NUM |mute]");
	
	// reuse buffer
	memset(readbuffer, '\0', BUFSIZE);

	// convert integer to string-ish
	snprintf(readbuffer, 7, "%d", soundval);

	char argbuffer[BUFSIZE];
	memset(argbuffer, '\0', BUFSIZE);
	strcpy(argbuffer, readbuffer);
	strcat(argbuffer, "%");

	int pid = fork();

	// otrok
	if (pid == 0) {
		int status;

		char *args[5]; 
		
		args[0] = "pactl";
		args[2] = "@DEFAULT_SINK@";
		args[4] = NULL;
		if (soundval < 0){
			args[1] = "set-sink-mute";
			args[3] = "toggle";
		}
		else {
			args[1] = "set-sink-volume";
			args[3] = argbuffer;
		}

		execv("/bin/pactl", args);
	}
	// starš
	else if (pid > 0) {
			
		// move to start of file and write from buffer
		lseek(fd, 0, SEEK_SET);
		write(fd, readbuffer, BUFSIZE);

		waitpid(pid, NULL, 0);
	}
	else {
		perror("Fork error!");
		exit(1);
	}
	
	close(fd);

	return 0;
}
