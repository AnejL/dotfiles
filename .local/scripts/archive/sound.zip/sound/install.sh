#!/bin/bash
sudo unlink /usr/bin/soundmgr
sudo ln -s /home/anej/Documents/Scripts/sound/soundmanager.sh /usr/bin/soundmgr
#sudo ln -s /home/anej/Documents/Scripts/sound/getselected.sh /usr/bin/soundswitch
