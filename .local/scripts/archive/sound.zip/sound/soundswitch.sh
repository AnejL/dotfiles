#!/bin/sh
SOUNDDIR="$HOME/.config/sound"

# TODO get all the info from getselected command
index=$(soundmgr get-index)
profile=$(soundmgr get-profile)
title=$(soundmgr get-title)


# presume that files now exist
currentdevice=$(cat $SOUNDDIR/selected) 

# device
computer=$(cat $HOME/.config/profile) 

# increment device index by one
# so next time this script runs it gets the next device
currentdevice=$(($currentdevice+1))
devicenum=$(cat $SOUNDDIR/devices_$computer | wc -l)

# if counter overflows reset it to 1
if [ $currentdevice -gt $devicenum ]; then
	currentdevice=$(($currentdevice-$devicenum))
fi

# write new count to file
echo $currentdevice > $SOUNDDIR/selected &

# set pulseaudio profile
pacmd set-card-profile $index $profile &
#echo "pacmd set-card-profile $index $profile"

# send status notification
notify-send "Selected audio device" "$title" #&

exit 0
