#!/bin/sh
SOUNDDIR="$HOME/.config/sound"
#devprofile=$(cat $SOUNDDIR/profile)
devprofile=$(cat $HOME/.config/profile)

devicesfile="$SOUNDDIR/devices_$devprofile"

if [ ! -f "$devicesfile" ]; then
	# TODO find a way to automate this
	echo "Create file 'devices' in ~/.config/sound"
	echo "File syntax:\nPulseaudio-sink-index;profile-name;profile-title"
	exit 1
fi

# presume that files now exist
currentdevice=$(cat $SOUNDDIR/selected)

# TODO grab the selected line with sed
DEVICEPROFILE=$(cat $devicesfile | head -$currentdevice | tail -1)

# extract device info
index=$(echo $DEVICEPROFILE | cut - -d ';' -f1)
profile=$(echo $DEVICEPROFILE | cut - -d ';' -f2)
title=$(echo $DEVICEPROFILE | cut - -d ';' -f3)

# possibilities
# - index
# - profile
# - title

output=""

if [ $# -gt 0 ]; then
	# TODO loop through arguments and count what should you return
	for arg in "$@"; do
		if [ "$arg" = "index" ] || [ "$arg" = "i" ]; then
			output="$output$index "
		elif [ "$arg" = "profile" ] || [ "$arg" = "p" ]; then
			output="$output$profile "
		elif [ "$arg" = "title" ] || [ "$arg" = "t" ]; then
			output="$output$title "
		else
			echo "Error: $arg is not a valid option!"
		fi
	done
else
	output=$(echo $DEVICEPROFILE | tr ';' ' ')
fi

echo $output
exit 0
