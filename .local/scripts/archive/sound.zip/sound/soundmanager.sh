#!/bin/sh
SMDIR="$HOME/Documents/Scripts/sound"

if [ "$1" = "switch" ]; then
	$SMDIR/soundswitch.sh
elif [ "$1" = "get-index" ]; then
	$SMDIR/getselected.sh index 
elif [ "$1" = "get-profile" ]; then
	$SMDIR/getselected.sh profile
elif [ "$1" = "get-title" ]; then
	$SMDIR/getselected.sh title 
elif [ "$1" = "set-profile" ]; then
	$SMDIR/setprofile.sh $2
elif [ "$1" = "inc" ]; then
	$SMDIR/control.sh inc
elif [ "$1" = "dec" ]; then
	$SMDIR/control.sh dec
elif [ "$1" = "mute" ]; then
	$SMDIR/control.sh mute
fi

exit 0
