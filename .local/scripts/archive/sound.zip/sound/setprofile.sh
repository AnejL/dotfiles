#!/bin/sh
if [ $# -eq 0 ] || [ "$1" = "--help" ]; then
	echo "help message"
	exit 1
fi

echo "$1" > $HOME/.config/profile
